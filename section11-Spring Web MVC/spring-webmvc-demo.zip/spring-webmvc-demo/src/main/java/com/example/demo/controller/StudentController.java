package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.dto.StudentQueryDto;
import com.example.demo.model.Student;
import com.example.demo.service.StudentService;


@Controller
@RequestMapping("/student")

public class StudentController extends BaseController {
    
    @Autowired
    StudentService studentService;

    
    @RequestMapping(path = { "", "/", "/list" })
    public String list(Model model, @ModelAttribute StudentQueryDto queryDto) {

        if (queryDto.getCurrentPage() == null)
            queryDto.setCurrentPage(currentPage);
        if (queryDto.getPageSize() == null)
            queryDto.setPageSize(pageSize);

        Page<Student> page = studentService.findAll(queryDto,
                                                  PageRequest.of(queryDto.getCurrentPage() - 1,
                                                                 queryDto.getPageSize(),
                                                                 Sort.by(Direction.ASC, "name")));
        model.addAttribute("page", page);
        model.addAttribute("queryDto", queryDto);
        
        return "/student/student-list";
    }
    
    

    @RequestMapping(path = { "/save" })
    public String save(Model model, @ModelAttribute Student student, RedirectAttributes redirectAttributes) {
        Student entity = new Student();
        if(student.getId() != null) {
            entity = studentService.findById(student.getId()).orElse(null);
            student.setName(entity.getName());
            student.setNo(entity.getNo());
        }
        
        studentService.save(student);
        
        return "redirect:/student/list";
    }

    @RequestMapping(path = { "/delete" })
    public String delete(Model model, Long id, RedirectAttributes redirectAttributes) {
        studentService.deleteById(id);
        redirectAttributes.addFlashAttribute("action_message_success", "刪除成功");
        return "redirect:/student/list";
    }

    
}
