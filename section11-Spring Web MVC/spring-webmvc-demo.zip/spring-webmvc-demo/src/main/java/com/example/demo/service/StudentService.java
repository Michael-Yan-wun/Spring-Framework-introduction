package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.example.demo.entity.CommonEntityDao;
import com.example.demo.model.Student;
import com.example.demo.model.StudentDao;
import com.example.demo.util.NOGenerator;

@Service
public class StudentService extends SoftDeleteEntityService<Student, Long> {

    private StudentDao studentDao;
    private NOGenerator ng;
    

    @Autowired
    public StudentService(StudentDao StudentDao, NOGenerator ng) {
        this.studentDao = StudentDao;
        this.ng = ng;
    }

    public Optional<Student> findByStudentname(String Studentname) {
        return studentDao.findByStudentname(Studentname);
    }
    

    public Optional<Student> findByNO(String no) {
        return studentDao.findByNO(no);
    }

    
    @Override
    public <S extends Student> S save(S entity) {
        synchronized (StudentService.class) {
            if (!StringUtils.hasText(entity.getNo()))
                entity.setNo(ng.Student());
            return super.save(entity);
        }
    }

    @Override
    public <S extends Student> List<S> saveAll(Iterable<S> entities) {
        List<S> list = new ArrayList<>();
        for (S e : entities) {
            list.add(this.save(e));
        }
        return list;
    }

    @Override
    protected CommonEntityDao<Student, Long> getCommonEntityDao() {
        return studentDao;
    }

}
