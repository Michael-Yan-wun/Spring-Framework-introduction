package com.example.demo.model;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.CommonEntityDao;

@Repository
public interface StudentDao extends CommonEntityDao<Student, Long> {

    @Query("select max(u.no) from Student u where u.deleted=false")
    public String maxNO();

    @Query("select u from Student u where u.name=:name and u.deleted=false")
    public List<Student> findByName(@Param("name") String name);
    
    @Query("select u from Student u where u.name=:name and u.deleted=false")
    public Optional<Student> findByStudentname(@Param("name") String Studentname);

    @Query("select u from Student u where u.no=:no and u.deleted=false")
    public Optional<Student> findByNO(@Param("no") String no);

}
