package com.example.demo.util;

import java.text.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.StudentDao;

@Component
public class NOGenerator {

    
    private StudentDao studentDao;


    public String Student() {
        NumberFormat format = new DecimalFormat("0000");
        String max = studentDao.maxNO();
        String no = null;
        if (max == null)
            no = format.format(1);
        else
            no = format.format(Integer.parseInt(max) + 1);
        return no;
    }

    

    @Autowired
    public void setStudentDao(StudentDao StudentDao) {
        this.studentDao = StudentDao;
    }
}
