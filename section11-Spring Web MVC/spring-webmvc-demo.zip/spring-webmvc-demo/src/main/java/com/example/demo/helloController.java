package com.example.demo;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class helloController {

	@RequestMapping("/hello")
	public ModelAndView hello() {
        return new ModelAndView("hello"); // 根據 view resolver mapping 至 hello.jsp
    }
	
	@RequestMapping("/")
    public String index(Model model) {
        //SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d yyyy : HH:mm:ss:SSS z");
        SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd : HH:mm:ss:SSS");
        Date now = new Date();
        String dateStr = dateFormat.format( now );
        model.addAttribute("time", dateStr);
        return "index";
    }
}
