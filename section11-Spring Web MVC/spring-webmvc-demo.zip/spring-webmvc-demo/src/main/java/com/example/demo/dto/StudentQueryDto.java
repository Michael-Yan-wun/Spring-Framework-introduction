package com.example.demo.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import com.example.demo.model.Role;
import com.example.demo.model.Student;

public class StudentQueryDto extends CommonQueryDto implements Specification<Student> {

    private static final long serialVersionUID = 2390362670106371340L;

    private String nameLike;
    private String noLike;
    private Role role;
    private List<Role> roleIn = new ArrayList<>();

    @Override
    public Predicate toPredicate(Root<Student> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

        List<Predicate> predicates = new ArrayList<>();
        predicates.add(cb.equal(root.get("deleted"), false));
        
        if (StringUtils.hasText(nameLike))
            predicates.add(cb.like(root.<String> get("name"), '%' + nameLike + '%'));
        if (StringUtils.hasText(noLike))
            predicates.add(cb.like(root.<String> get("no"), '%' + noLike + '%'));
        if (role != null && role.getId() != null)
            predicates.add(cb.isMember(role, root.get("roles")));        
        if(roleIn.size()>0) {
            List<Predicate> orClauses = new ArrayList<>();
            for(Role r:roleIn) {
                orClauses.add(cb.isMember(r, root.get("roles")));
            }
            predicates.add(cb.or(orClauses.toArray(new Predicate[orClauses.size()])));
        }

        if (predicates.size() > 0)
            return cb.and(predicates.toArray(new Predicate[predicates.size()]));
        return cb.conjunction();
    }
   

    public String getNameLike() {
        return nameLike;
    }

    public StudentQueryDto setNameLike(String nameLike) {
        this.nameLike = nameLike;
        return this;
    }

    public String getNoLike() {
        return noLike;
    }

    public StudentQueryDto setNoLike(String noLike) {
        this.noLike = noLike;
        return this;
    }

    public Role getRole() {
        return role;
    }

    public StudentQueryDto setRole(Role role) {
        this.role = role;
        return this;
    }


    public List<Role> getRoleIn() {
        return roleIn;
    }

    public StudentQueryDto setRoleIn(List<Role> roleIn) {
        this.roleIn = roleIn;
        return this;
    }
    
}
