package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.example.demo.entity.SoftDeleteEntity;

@Entity
@Table(name = "role")
public class Role extends SoftDeleteEntity {

    private static final long serialVersionUID = -1259715134928519774L;
    private Long id;
    private String name;
    private String alias;
    private Boolean immutable = false; //true=不可修改，系統必需
    
    public static final String DEFAULT_ALIAS_ADMIN = "R_ADMIN";
    public static final String DEFAULT_ALIAS_MANAGER = "R_MANAGER";
    public static final String DEFAULT_ALIAS_STUEDNT = "R_STUDENT";

    public Role() {
        super();
    }

    public Role(String alias, String name) {
        super();
        this.alias = alias;
        this.name = name;
    }

    public Role(String alias, String name, Boolean immutable) {
        super();
        this.name = name;
        this.alias = alias;
        this.immutable = immutable;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "name", length = 50)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public Boolean getImmutable() {
        return immutable;
    }

    public void setImmutable(Boolean immutable) {
        this.immutable = immutable;
    }

}
